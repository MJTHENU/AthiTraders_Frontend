import React from 'react';
import Sidebar from '../component/Sidebar';

const admindashboard = () => {
  return (
    <>
      <Sidebar />
      <div>
        <h1>Hello</h1>
        Admin Dashboard
      </div>
    </>
  );
}

export default admindashboard;
